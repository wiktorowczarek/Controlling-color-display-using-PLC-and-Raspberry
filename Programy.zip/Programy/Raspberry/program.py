import time
import board
import neopixel

###################### MODBUS ################

    
from pymodbus.client.sync import ModbusTcpClient as ModbusClient

client = ModbusClient('169.254.251.11')

connection = client.connect()

result = client.read_holding_registers(0, 123)
result2 = client.read_holding_registers(123, 123)
result3 = client.read_holding_registers(246, 123)     #(adres poczatkowy, ilosc wyswietlanych adresow)
result4 = client.read_holding_registers(369, 123)
result5 = client.read_holding_registers(492, 123)
result6 = client.read_holding_registers(615, 123)
result7 = client.read_holding_registers(738, 30)

########################## WARTOSCI DO TABLICY ###################
tab0=[]
tab1=[]
tab2=[]
tab3=[]
tab4=[]
tab5=[]
tab6=[]

i=0

for i in range(123):
    
    tab0.append(result.registers[i])
    tab1.append(result2.registers[i])
    tab2.append(result3.registers[i])
    tab3.append(result4.registers[i])
    tab4.append(result5.registers[i])
    tab5.append(result6.registers[i])
    i+=1

i=0

for i in range(30):
    tab6.append(result7.registers[i])
    i+=1

tab =[]
tab = tab0 + tab1 + tab2 + tab3 + tab4 + tab5 + tab6


############################## USTAWIENIE MATRYCY ##################
pixel_pin = board.D18
pixel_liczba = 256

pixels = neopixel.NeoPixel( pixel_pin, pixel_liczba,brightness=0.1,
                            auto_write=False, pixel_order=neopixel.RGB)


i = 0
j = 0
for i in range(256):
    j = i * 3
    pixels[i] = (tab[j], tab[j+1], tab[j+2])




client.close()

pixels.show()