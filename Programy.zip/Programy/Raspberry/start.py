while True:
    from subprocess import call
    call(["sudo", "python3", "/home/pi/Documents/Wiktor/program.py"])
